import json

# 读取文件
with open('bot_teams.txt', 'r', encoding='utf-8') as file:
    data = json.load(file)

# 筛选 is_male 为 true 的骑手
data['riders'] = [rider for rider in data['riders'] if rider['is_male'] is True]

# 写回文件
with open('bot.txt', 'w', encoding='utf-8') as file:
    json.dump(data, file, indent=2, ensure_ascii=False)